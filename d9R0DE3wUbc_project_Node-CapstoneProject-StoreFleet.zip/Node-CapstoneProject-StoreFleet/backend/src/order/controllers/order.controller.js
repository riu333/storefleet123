// Please don't change the pre-written code
// Import the necessary modules here

import { createNewOrderRepo } from "../model/order.repository.js";
import { ErrorHandler } from "../../../utils/errorHandler.js";

export const createNewOrder = async (req, res, next) => {
  try {
    const orderData = {
      ...req.body,
      user: req.user._id,
    };
    const newOrder = await createNewOrderRepo(orderData);
    res.status(201).json({ success: true, order: newOrder });
  } catch (error) {
    return next(new ErrorHandler(400, error));
  }
};
