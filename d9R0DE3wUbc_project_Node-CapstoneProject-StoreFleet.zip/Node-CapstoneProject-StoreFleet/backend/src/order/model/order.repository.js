import OrderModel from "./order.schema.js";

export const createNewOrderRepo = async (data) => {
  // Write your code here for placing a new order
  try{
  const newOrder=new OrderModel(data);
 const savedOrder= await newOrder.save();
 return savedOrder;
}catch(error){
  throw error;
}
};
