import server from "./app.js";
import { connectDB } from "./config/db.js";
import path from 'path';
import dotenv from 'dotenv';
const configPath = path.resolve( "config", "uat.env");
dotenv.config({ path: configPath });



const serverStar = server.listen(process.env.PORT, async (err) => {
  if (err) {
    console.log(`server failed with error ${err}`);
  } else {
    console.log(process.env.port);
    console.log(configPath);
    await connectDB();
    console.log(`server is running at http://localhost:${process.env.PORT}`);
  }
});
