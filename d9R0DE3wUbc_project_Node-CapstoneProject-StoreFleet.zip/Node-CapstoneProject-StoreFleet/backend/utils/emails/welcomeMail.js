// Import the necessary modules here
import nodemailer from 'nodemailer';
export const sendWelcomeEmail = async (user) => {
  //create a transporter using your email service provider
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

  //define the email options
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: user.email,
    subject: 'Welcome to StoreFleet',
    text: `Hello ${user.name},\n\nWelcome to StoreFleet! We're excited to have you on board.\n\nBest regards,\nThe StoreFleet Team`,
    html: `
      <div style="font-family: Arial, sans-serif; color: #222;">
        <img src="https://files.codingninjas.in/logo1-32230.png" alt="StoreFleet Logo" style="width:120px; margin-bottom:16px;" />
        <h2>Welcome to StoreFleet, ${user.name}!</h2>
        <p>We're excited to have you on board.</p>
        <p>Best regards,<br/>The StoreFleet Team</p>
      </div>
    `,
  };
  //send the email
  try {
    await transporter.sendMail(mailOptions);
    console.log(`Welcome email sent to ${user.email}`);
  } catch (error) {
    console.error('Error sending welcome email:', error);
  }
};


